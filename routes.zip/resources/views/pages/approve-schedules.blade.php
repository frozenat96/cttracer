@extends('layouts.app')

@section('style')

@endsection

@section('content')
<div class="row">
    <div class="col-md-12 justify-align-center" id="index_content1">
        <h4>APPROVE SCHEDULES</h4>
    </div>
</div>
@endsection