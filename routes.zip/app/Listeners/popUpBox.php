<?php

namespace App\Listeners;

use App\Events\eventTrigger;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

class popUpBox
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  eventTrigger  $event
     * @return void
     */
    public function handle(eventTrigger $event)
    {
        //
    }
}
