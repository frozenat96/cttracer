<html>
<head>   
</head>
<body style="background-color:blanchedalmond">

<div class="row">
    <div class="col-md-12">
        <center><h4>VISION</h4></center>
        <p class="jsfy">
            A leading Christian institution committed to total human development for the well-being of society and environment.
        </p>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <center><h4>MISSION</h4></center>
        <p class="jsfy">		
            Infuse into the academic learning the Christian faith 
            anchored on the gospel of Jesus Christ.Provide an 
            environment where Christian fellowship and relationship can 
            be nurtured and promoted.Provide opportunities for growth 
            and excellence in every dimension of the University life in 
            order to
            strengthen competence, character and faith.Instill in all 
            members of the University community an enlightened social 
            consciousness and a deep
            sense of justice and compassion.Promote unity among peoples 
            and contribute to national development. 
        </p>
    </div>
</div>
				


</body>
</html>